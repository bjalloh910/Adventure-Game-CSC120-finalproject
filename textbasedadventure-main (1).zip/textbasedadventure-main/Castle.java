import java.util.Scanner;


public class Castle extends Location {
    
    
    Scanner Castle_location ;



    
    
    public Castle (String Road_Name, String Road_Adress) {
        this.Road_Name = "Castle " ; 
        this.Road_Adress =  "King's Road ";
        // Scanner.Castle_location  = new 
        
    } 





























    public static void main(String[] args) {



    
    }

}
