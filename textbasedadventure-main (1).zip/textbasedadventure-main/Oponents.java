public class Oponents {
    
    
    Location current_Location;
    // name of the oponents 
}
